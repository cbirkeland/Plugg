﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp24
{
    class Program
    {
        static void Main(string[] args)
        {
            char myChar = (char)97;
            char myChar1 = (char)98;
            char myChar2 = (char)99;
            Console.WriteLine(myChar);
            Console.WriteLine(myChar1);
            Console.WriteLine(myChar2);

            Console.WriteLine("Denna kod genererar Anna Books one hit wonder");
        }
    }
}
