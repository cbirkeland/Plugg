﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp25
{
    class Program
    {
        static void Main(string[] args)
        {

            // Ändrade int till Double för att svaret skulle bli kompatibelt med decimalen = 0,5 

            double a = 1;
            double b = 2;

            double c = a / b;

            Console.WriteLine(c);
        }
    }
}
