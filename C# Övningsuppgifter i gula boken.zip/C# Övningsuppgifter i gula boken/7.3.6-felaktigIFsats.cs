﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp30
{
    class Program
    {
        static void Main(string[] args)
        {

            // Behövde ändra från = till ==
            int var = 10;
            if (var == 10)
            {
                Console.WriteLine("Den är 10");
            }
                
        }
    }
}
