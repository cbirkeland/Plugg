﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp14
{
    class Program
    {
        static void Main(string[] args)
        {
            // Programmet startar
            // Skriv ut temperatur
            // Skriv ut meny: Mata in temperatur
            // mata in temperatur
            // användaren trycker "q" eller "Q", isådantfall STOPPAR programmet
            // om inte -> Temperatur < 17
            // Om temperaturen inte är <17, 
            // Temperatur >25, gå till "Skriv ut temperatur"
            // om temperaturen är < 17
            // Skriv ut temperatur = 0 . "Skriv ut temperatur"



                
             
        }
    }
}
